package com.example.apigatewayimplementation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayImplementationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayImplementationApplication.class, args);
	}

}
