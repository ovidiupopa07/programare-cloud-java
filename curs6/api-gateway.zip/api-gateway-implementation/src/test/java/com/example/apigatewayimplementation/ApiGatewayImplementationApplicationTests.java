package com.example.apigatewayimplementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayImplementationApplicationTests {

	@Test
	void contextLoads() {
	}

}
