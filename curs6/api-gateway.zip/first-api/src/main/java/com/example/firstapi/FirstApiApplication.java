package com.example.firstapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class FirstApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstApiApplication.class, args);
	}


	@RestController
	public static class FirstApiController {


		@GetMapping("/greeting")
		public String sayHello(@RequestParam("name") String name) {
			System.out.println("request a new greeting");
			return "hello " + name;
		}
	}
}
