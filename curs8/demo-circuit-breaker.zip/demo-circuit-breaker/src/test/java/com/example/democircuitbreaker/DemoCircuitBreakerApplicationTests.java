package com.example.democircuitbreaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCircuitBreakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
